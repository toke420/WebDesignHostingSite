WEBTECHPROS LOGO PACK
=====================

FOLDERS
  svg/       Vector logos. Best for print, signage and design tools. Text is converted to outlines,
             so no fonts are needed.
  png/       Transparent images at 400, 800, 1600 and 3200 px wide. Icons from 16 to 1024 px.
  jpg/       Logos on a solid background (for apps that don't support transparency).
  favicon/   Website icons: favicon.ico, favicon.svg, Apple and Android icons, web manifest
             and the HTML snippet to paste into your site.
  social/    Profile pictures for Facebook, Instagram, LinkedIn, Google Business and X.
  banners/   Ready-to-upload advertising and cover images (PNG and JPG):
             leaderboard-728x90               728x90  Google Display leaderboard
             billboard-970x250                970x250  Google Display billboard
             mobile-banner-320x50             320x50  Google Display mobile banner
             large-mobile-320x100             320x100  Google Display large mobile
             medium-rectangle-300x250         300x250  Google Display / Facebook right column
             large-rectangle-336x280          336x280  Google Display large rectangle
             skyscraper-160x600               160x600  Google Display wide skyscraper
             half-page-300x600                300x600  Google Display half page
             social-link-1200x628             1200x628  Facebook / LinkedIn link and ad image
             instagram-square-1080x1080       1080x1080  Instagram & Facebook feed post
             instagram-portrait-1080x1350     1080x1350  Instagram portrait post
             story-1080x1920                  1080x1920  Instagram / Facebook story and reel cover
             facebook-cover-820x312           820x312  Facebook page cover
             linkedin-banner-1584x396         1584x396  LinkedIn page banner
             x-header-1500x500                1500x500  X (Twitter) header
             youtube-banner-2560x1440         2560x1440  YouTube channel art (safe area centred)
             email-signature-600x150          600x150  Email signature banner

WHICH LOGO SHOULD I USE?
  On dark backgrounds   logo-horizontal-dark (has its own dark box) or logo-horizontal-white
                        / logo-horizontal-on-dark-transparent
  On light backgrounds  logo-horizontal-light
  One colour printing   logo-horizontal-black or logo-horizontal-white
  Small square spaces   icon-dark or icon-yellow

COLOURS
  Signal yellow   #EFD929   RGB 239 217 41
  Ink black       #111210   RGB 17 18 16
  Paper white     #F3F2ED   RGB 243 242 237
  Muted grey      #8D8F84   RGB 141 143 132

FONTS
  Headings & logo   Space Grotesk (SIL Open Font License)
  Body text         Manrope (SIL Open Font License)

CLEAR SPACE & SIZE
  Keep empty space around the logo at least the height of the "w." mark.
  Don't use the horizontal logo smaller than 120 px wide on screen or 30 mm in print;
  use the icon instead.

PLEASE DON'T
  Stretch, rotate or recolour the logo, add shadows or outlines, or place the yellow
  version on light or busy backgrounds.

Regenerate this pack from the website repository with: npm run build:logo
